﻿namespace EjercicioDeC_2_Entradapantalla_Dato
{
    internal class Program
    {
        static void Main(string[] args)
        {
           ;

            Console.WriteLine("Por favor, ingresa un numero:");
            string texto = Console.ReadLine();
            Console.WriteLine("Ingresaste el numero: " + texto);

        }
    }
}