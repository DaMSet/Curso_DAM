﻿namespace David_Martinez_Seto_Examen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");


        }
    }
}